// Mobile Menü

const menuBtn = document.querySelector(".menu-btn");
const navLinks = document.querySelector(".nav-links");

menuBtn.addEventListener("click", () => {

    if (navLinks.style.display === "flex") {
        navLinks.style.display = "none";
    } else {
        navLinks.style.display = "flex";

        navLinks.style.position = "absolute";
        navLinks.style.top = "80px";
        navLinks.style.left = "0";
        navLinks.style.width = "100%";
        navLinks.style.flexDirection = "column";
        navLinks.style.alignItems = "center";
        navLinks.style.padding = "30px";
        navLinks.style.background = "#0d0d13";
    }

});


// Navbar Schatten beim Scrollen

window.addEventListener("scroll", () => {

    const navbar = document.querySelector(".navbar");

    if (window.scrollY > 50) {
        navbar.style.boxShadow = "0 10px 30px rgba(0,0,0,0.3)";
    } else {
        navbar.style.boxShadow = "none";
    }

});


// Kleine Animation für Cards

const cards = document.querySelectorAll(
    ".about-card, .game-card"
);

cards.forEach(card => {

    card.addEventListener("mouseenter", () => {
        card.style.boxShadow =
            "0 20px 40px rgba(0,0,0,0.4)";
    });

    card.addEventListener("mouseleave", () => {
        card.style.boxShadow = "none";
    });

});