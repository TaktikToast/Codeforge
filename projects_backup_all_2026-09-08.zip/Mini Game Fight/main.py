imprt random


class Player:
    def __init__(self, name):
        self.name = name
        self.health = 100
        self.gold = 50
        self.level = 1
        self.inventory = []


def status(player):
    print()
    print("📊 STATUS 📊")
    print("--------------------")
    print("🧙 Name:", player.name)
    print("⭐ Level:", player.level)
    print("❤️ Leben:", player.health)
    print("💰 Gold:", player.gold)
    print("🎒 Inventar:", player.inventory)
    print("--------------------")


def fight(player):
    enemies = ["Goblin", "Ork", "Skelett"]
    enemy = random.choice(enemies)
    enemy_hp = random.randint(40, 70)

    print()
    print("⚔️ KAMPF ⚔️")
    print("👹 Ein", enemy, "greift dich an!")
    print("❤️ Gegner Leben:", enemy_hp)

    while enemy_hp > 0 and player.health > 0:

        print()
        print("🧙 Dein Leben:", player.health)
        print("👹 Gegner Leben:", enemy_hp)
        print()
        print("⚔️ 1 - Angreifen")
        print("🧪 2 - Heiltrank benutzen")
        print("🏃 3 - Fliehen")

        choice = input("👉 Auswahl: ")

        if choice == "1":
            damage = random.randint(10, 25)
            enemy_hp = enemy_hp - damage

            print("⚔️💥 Du machst", damage, "Schaden!")

            if enemy_hp <= 0:
                gold = random.randint(10, 30)

                player.gold = player.gold + gold
                player.level = player.level + 1

                print("🏆 Du hast den", enemy, "besiegt!")
                print("💰 Du bekommst", gold, "Gold!")
                print("⭐ LEVEL UP! Du bist jetzt Level", player.level)

                return

            enemy_damage = random.randint(5, 15)
            player.health = player.health - enemy_damage

            print("👹💥 Der Gegner macht", enemy_damage, "Schaden!")

        elif choice == "2":

            if "Heiltrank" in player.inventory:

                player.inventory.remove("Heiltrank")

                player.health = player.health + 30

                if player.health > 100:
                    player.health = 100

                print("🧪💚 Du benutzt einen Heiltrank!")
                print("❤️ Dein Leben:", player.health)

            else:
                print("❌ Du hast keinen Heiltrank!")

        elif choice == "3":
            print("🏃💨 Du bist geflohen!")
            return

        else:
            print("❌ Ungültige Eingabe!")

    if player.health <= 0:
        print("💀 Du wurdest besiegt!")


def shop(player):

    print()
    print("🏪 SHOP 🏪")
    print("--------------------")
    print("💰 Dein Gold:", player.gold)
    print()
    print("🧪 1 - Heiltrank - 20 Gold")
    print("🚪 2 - Zurück")

    choice = input("👉 Auswahl: ")

    if choice == "1":

        if player.gold >= 20:

            player.gold = player.gold - 20

            player.inventory.append("Heiltrank")

            print("🧪✅ Heiltrank gekauft!")

        else:
            print("❌💰 Nicht genug Gold!")

    elif choice == "2":
        print("🚪 Du verlässt den Shop.")

    else:
        print("❌ Ungültige Eingabe!")


def treasure(player):

    print()
    print("🎁 SCHATZTRUHE 🎁")
    print("Du findest eine geheimnisvolle Truhe.")
    print()
    print("🔓 1 - Öffnen")
    print("🚶 2 - Ignorieren")

    choice = input("👉 Auswahl: ")

    if choice == "1":

        chance = random.randint(1, 100)

        if chance <= 70:

            gold = random.randint(10, 50)

            player.gold = player.gold + gold

            print("🎉💰 Du findest", gold, "Gold!")

        else:

            damage = random.randint(5, 20)

            player.health = player.health - damage

            print("💥💀 Falle!")
            print("💔 Du verlierst", damage, "Leben!")

    elif choice == "2":
        print("🚶 Du gehst weiter...")

    else:
        print("❌ Ungültige Eingabe!")


def game():

    print("🐍🎮 PYTHON ABENTEUER 🎮🐍")
    print()
    print("⚔️ 👹 💰 🧪 🎁 🏪 🏆")
    print()

    name = input("🧙 Wie heißt dein Held? ")

    if name == "":
        name = "Held"

    player = Player(name)

    print()
    print("🎉 Willkommen,", player.name + "!")

    while player.health > 0:

        print()
        print("🏰 HAUPTMENÜ 🏰")
        print("--------------------")
        print("⚔️ 1 - Kämpfen")
        print("🏪 2 - Shop")
        print("🎁 3 - Schatztruhe suchen")
        print("📊 4 - Status")
        print("👋 5 - Beenden")

        choice = input("👉 Auswahl: ")

        if choice == "1":
            fight(player)

        elif choice == "2":
            shop(player)

        elif choice == "3":
            treasure(player)

        elif choice == "4":
            status(player)

        elif choice == "5":
            print()
            print("👋 Danke fürs Spielen!")
            print("🐍🎮 Bis zum nächsten Abenteuer!")
            break

        else:
            print("❌ Bitte wähle eine Zahl von 1 bis 5.")

    if player.health <= 0:
        print()
        print("💀 GAME OVER 💀")
        print("☠️ Dein Held wurde besiegt!")


game()