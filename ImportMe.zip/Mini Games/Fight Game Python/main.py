import random

class Player:
    def __init__(self, name):
        self.name = name
        self.health = 100
        self.gold = 50
        self.level = 1
        self.inventory = []

def status(player):
    print()
    print("STATUS")
    print("--------------------")
    print("Name:", player.name)
    print("Level:", player.level)
    print("Health:", player.health)
    print("Gold:", player.gold)
    print("Inventory:", player.inventory)
    print("--------------------")

def fight(player):
    enemies = ["Goblin", "Orc", "Skeleton"]
    enemy = random.choice(enemies)
    enemy_hp = random.randint(40, 70)

    print()
    print("BATTLE")
    print("--------------------")
    print("A", enemy, "attacks you!")
    print("Enemy Health:", enemy_hp)

    while enemy_hp > 0 and player.health > 0:
        print()
        print("Your Health:", player.health)
        print("Enemy Health:", enemy_hp)
        print()
        print("1 - Attack")
        print("2 - Use Health Potion")
        print("3 - Run Away")

        choice = input("Choose an option: ")

        if choice == "1":
            if "Sword" in player.inventory:
                damage = random.randint(20, 35)
                print("You attack with your Sword!")
            else:
                damage = random.randint(10, 25)
                print("You attack without a weapon!")

            enemy_hp -= damage
            print("You deal", damage, "damage!")

            if enemy_hp <= 0:
                gold = random.randint(10, 30)
                player.gold += gold
                player.level += 1

                print()
                print("You defeated the", enemy + "!")
                print("You received", gold, "gold!")
                print("LEVEL UP! You are now level", player.level)
                return

            enemy_damage = random.randint(5, 15)
            player.health -= enemy_damage
            print("The enemy deals", enemy_damage, "damage!")

        elif choice == "2":
            if "Health Potion" in player.inventory:
                player.inventory.remove("Health Potion")
                player.health += 30

                if player.health > 100:
                    player.health = 100

                print("You used a Health Potion!")
                print("Your Health:", player.health)
            else:
                print("You don't have a Health Potion!")

        elif choice == "3":
            print("You ran away!")
            return

        else:
            print("Invalid input!")

    if player.health <= 0:
        print("You were defeated!")

def shop(player):
    while True:
        print()
        print("SHOP")
        print("--------------------")
        print("Your Gold:", player.gold)
        print()
        print("1 - Sword - 40 Gold")
        print("2 - Health Potion - 20 Gold")
        print("3 - View Inventory")
        print("4 - Leave Shop")

        choice = input("Choose an option: ")

        if choice == "1":
            if "Sword" in player.inventory:
                print("You already own a Sword!")
            elif player.gold >= 40:
                player.gold -= 40
                player.inventory.append("Sword")
                print("You bought a Sword!")
                print("Your attacks are now stronger!")
            else:
                print("You don't have enough gold!")

        elif choice == "2":
            if player.gold >= 20:
                player.gold -= 20
                player.inventory.append("Health Potion")
                print("You bought a Health Potion!")
            else:
                print("You don't have enough gold!")

        elif choice == "3":
            status(player)

        elif choice == "4":
            print("You leave the shop.")
            return

        else:
            print("Invalid input!")

def treasure(player):
    print()
    print("TREASURE CHEST")
    print("--------------------")
    print("You discover a mysterious treasure chest.")
    print()
    print("1 - Open")
    print("2 - Ignore")

    choice = input("Choose an option: ")

    if choice == "1":
        chance = random.randint(1, 100)

        if chance <= 70:
            gold = random.randint(10, 50)
            player.gold += gold
            print("You found", gold, "gold!")
        else:
            damage = random.randint(5, 20)
            player.health -= damage
            print("It's a trap!")
            print("You lost", damage, "health!")

    elif choice == "2":
        print("You continue walking...")

    else:
        print("Invalid input!")

def game():
    print("PYTHON ADVENTURE")
    print("--------------------")

    name = input("What is your hero's name? ")

    if name == "":
        name = "Hero"

    player = Player(name)

    print()
    print("Welcome,", player.name + "!")

    while player.health > 0:
        print()
        print("MAIN MENU")
        print("--------------------")
        print("1 - Fight")
        print("2 - Shop")
        print("3 - Search for Treasure")
        print("4 - Status")
        print("5 - Quit")

        choice = input("Choose an option: ")

        if choice == "1":
            fight(player)

        elif choice == "2":
            shop(player)

        elif choice == "3":
            treasure(player)

        elif choice == "4":
            status(player)

        elif choice == "5":
            print()
            print("Thanks for playing!")
            print("See you on your next adventure!")
            break

        else:
            print("Please choose a number from 1 to 5.")

    if player.health <= 0:
        print()
        print("GAME OVER")
        print("Your hero was defeated!")

game()