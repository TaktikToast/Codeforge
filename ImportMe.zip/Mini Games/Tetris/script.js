"use strict";

/* =========================================================
   TETRIS
   ========================================================= */

const BOARD_WIDTH = 10;
const BOARD_HEIGHT = 20;

const COLORS = {
    O: "rgb(255,232,51)",
    I: "rgb(51,255,209)",
    S: "rgb(106,255,51)",
    Z: "rgb(255,51,83)",
    L: "rgb(255,129,51)",
    J: "rgb(64,100,255)",
    T: "rgb(160,62,255)"
};

const PIECES = {
    O: {
        rotations: [
            [
                [-1, 0],
                [0, 0],
                [-1, 1],
                [0, 1]
            ]
        ]
    },

    I: {
        rotations: [
            [
                [-2, 0],
                [-1, 0],
                [0, 0],
                [1, 0]
            ],
            [
                [0, -1],
                [0, 0],
                [0, 1],
                [0, 2]
            ]
        ]
    },

    S: {
        rotations: [
            [
                [0, 0],
                [1, 0],
                [-1, 1],
                [0, 1]
            ],
            [
                [0, -1],
                [0, 0],
                [1, 0],
                [1, 1]
            ]
        ]
    },

    Z: {
        rotations: [
            [
                [-1, 0],
                [0, 0],
                [0, 1],
                [1, 1]
            ],
            [
                [1, -1],
                [0, 0],
                [1, 0],
                [0, 1]
            ]
        ]
    },

    L: {
        rotations: [
            [
                [-1, 0],
                [0, 0],
                [1, 0],
                [-1, -1]
            ],
            [
                [0, -1],
                [0, 0],
                [0, 1],
                [1, 1]
            ],
            [
                [1, 0],
                [0, 0],
                [-1, 0],
                [1, 1]
            ],
            [
                [0, 1],
                [0, 0],
                [0, -1],
                [-1, -1]
            ]
        ]
    },

    J: {
        rotations: [
            [
                [-1, 0],
                [0, 0],
                [1, 0],
                [1, -1]
            ],
            [
                [0, -1],
                [0, 0],
                [0, 1],
                [1, 1]
            ],
            [
                [-1, 1],
                [-1, 0],
                [0, 0],
                [1, 0]
            ],
            [
                [-1, -1],
                [0, -1],
                [0, 0],
                [0, 1]
            ]
        ]
    },

    T: {
        rotations: [
            [
                [-1, 0],
                [0, 0],
                [1, 0],
                [0, -1]
            ],
            [
                [0, -1],
                [0, 0],
                [0, 1],
                [1, 0]
            ],
            [
                [0, 1],
                [0, 0],
                [-1, 0],
                [1, 0]
            ],
            [
                [0, -1],
                [0, 0],
                [0, 1],
                [-1, 0]
            ]
        ]
    }
};


/* =========================================================
   CANVAS
   ========================================================= */

const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const nextCanvases = [
    document.getElementById("nextCanvas1"),
    document.getElementById("nextCanvas2"),
    document.getElementById("nextCanvas3")
];

const nextContexts = nextCanvases.map(c => c.getContext("2d"));

let cellSize = 30;


/* =========================================================
   BOARD
   ========================================================= */

let board = [];

function createBoard() {
    board = [];

    for (let x = 0; x < BOARD_WIDTH; x++) {
        board[x] = [];

        for (let y = 0; y < BOARD_HEIGHT; y++) {
            board[x][y] = null;
        }
    }
}


/* =========================================================
   GAME STATE
   ========================================================= */

const game = {
    alive: true,

    score: 0,
    highScore: Number(localStorage.getItem("tetrisHighScore") || 0),

    level: 1,
    piecesRemaining: 10,

    tickRate: 500,
    lastTick: 0,

    current: null,
    next: [],

    scoreBonus: 0,
    difficultFlag: false
};


/* =========================================================
   PIECE
   ========================================================= */

class Piece {

    constructor(type) {
        this.type = type;
        this.color = COLORS[type];

        this.x = 5;
        this.y = 0;

        this.rotation = 0;
    }

    get blocks() {
        return PIECES[this.type].rotations[this.rotation];
    }

    rotate() {
        this.rotation =
            (this.rotation + 1) %
            PIECES[this.type].rotations.length;
    }

    clone() {
        const copy = new Piece(this.type);

        copy.x = this.x;
        copy.y = this.y;
        copy.rotation = this.rotation;

        return copy;
    }
}


/* =========================================================
   RANDOM PIECE
   ========================================================= */

function randomPiece() {

    const types = Object.keys(PIECES);

    const type =
        types[Math.floor(Math.random() * types.length)];

    return new Piece(type);
}


/* =========================================================
   COLLISION
   ========================================================= */

function checkCollision(piece, offsetX = 0, offsetY = 0, rotation = piece.rotation) {

    const blocks =
        PIECES[piece.type].rotations[rotation];

    for (const block of blocks) {

        const x =
            piece.x + block[0] + offsetX;

        const y =
            piece.y + block[1] + offsetY;

        if (x < 0 || x >= BOARD_WIDTH) {
            return true;
        }

        if (y >= BOARD_HEIGHT) {
            return true;
        }

        if (y >= 0 && board[x][y] !== null) {
            return true;
        }
    }

    return false;
}


/* =========================================================
   MOVE
   ========================================================= */

function movePiece(dx, dy) {

    if (!game.current) {
        return false;
    }

    if (
        !checkCollision(
            game.current,
            dx,
            dy
        )
    ) {

        game.current.x += dx;
        game.current.y += dy;

        if (dy > 0) {
            game.lastTick = performance.now();
            game.scoreBonus++;
        }

        return true;
    }

    return false;
}


/* =========================================================
   ROTATE
   ========================================================= */

function rotatePiece() {

    if (!game.current) {
        return false;
    }

    const oldRotation =
        game.current.rotation;

    const newRotation =
        (oldRotation + 1) %
        PIECES[game.current.type].rotations.length;

    if (
        !checkCollision(
            game.current,
            0,
            0,
            newRotation
        )
    ) {

        game.current.rotation =
            newRotation;

        return true;
    }

    // kleine Wall-Kicks
    const kicks = [-1, 1, -2, 2];

    for (const kick of kicks) {

        if (
            !checkCollision(
                game.current,
                kick,
                0,
                newRotation
            )
        ) {

            game.current.x += kick;
            game.current.rotation =
                newRotation;

            return true;
        }
    }

    return false;
}


/* =========================================================
   HARD DROP
   ========================================================= */

function hardDrop() {

    if (!game.current) {
        return;
    }

    let distance = 0;

    while (
        !checkCollision(
            game.current,
            0,
            1
        )
    ) {

        game.current.y++;
        distance++;
    }

    if (distance > 0) {
        game.scoreBonus +=
            distance * 2;
    }

    freezePiece();
}


/* =========================================================
   FREEZE PIECE
   ========================================================= */

function freezePiece() {

    if (!game.current) {
        return;
    }

    const affectedRows = [];

    for (const block of game.current.blocks) {

        const x =
            game.current.x + block[0];

        const y =
            game.current.y + block[1];

        if (
            x >= 0 &&
            x < BOARD_WIDTH &&
            y >= 0 &&
            y < BOARD_HEIGHT
        ) {

            board[x][y] =
                game.current.color;

            if (
                !affectedRows.includes(y)
            ) {
                affectedRows.push(y);
            }
        }
    }

    clearLines(affectedRows);

    game.current = null;

    spawnPiece();
}


/* =========================================================
   CLEAR LINES
   ========================================================= */

function clearLines(rows) {

    let multiplier = 0;
    let points = game.scoreBonus;

    rows.sort((a, b) => a - b);

    for (const row of rows) {

        let complete = true;

        for (let x = 0; x < BOARD_WIDTH; x++) {

            if (board[x][row] === null) {
                complete = false;
                break;
            }
        }

        if (!complete) {
            continue;
        }

        for (let x = 0; x < BOARD_WIDTH; x++) {

            board[x].splice(row, 1);
            board[x].unshift(null);
        }

        points +=
            100 +
            200 * multiplier;

        if (multiplier > 2) {
            points += 100;
        }

        multiplier++;
    }

    if (game.difficultFlag) {

        points =
            Math.floor(points * 1.5);

        game.difficultFlag = false;
    }

    if (points > 0) {

        game.score += points;

        game.scoreBonus = 0;

        if (multiplier > 3) {
            game.difficultFlag = true;
        }

        updateScore();
    }
}


/* =========================================================
   SPAWN
   ========================================================= */

function spawnPiece() {

    game.current =
        game.next.shift();

    game.next.push(
        randomPiece()
    );

    if (!game.current) {
        game.current =
            game.next.shift();

        game.next.push(
            randomPiece()
        );
    }

    game.current.x = 5;
    game.current.y = 0;

    game.current.rotation = 0;

    if (
        checkCollision(
            game.current
        )
    ) {

        gameOver();
        return;
    }

    game.piecesRemaining--;

    if (
        game.piecesRemaining <= 0
    ) {

        advanceLevel();
    }

    updateNextPieces();
}


/* =========================================================
   LEVEL
   ========================================================= */

function advanceLevel() {

    game.level++;

    game.tickRate =
        Math.floor(
            555 *
            Math.exp(game.level / -10)
        );

    game.piecesRemaining =
        Math.floor(
            5000 / game.tickRate
        );

    updateScore();
}


/* =========================================================
   PROJECTION
   ========================================================= */

function getProjectionY() {

    if (!game.current) {
        return 0;
    }

    let distance = 0;

    while (
        !checkCollision(
            game.current,
            0,
            distance + 1
        )
    ) {

        distance++;
    }

    return distance;
}


/* =========================================================
   DRAW BOARD
   ========================================================= */

function drawBoard() {

    ctx.clearRect(
        0,
        0,
        canvas.width,
        canvas.height
    );

    // Hintergrund
    ctx.fillStyle =
        "rgb(28,30,34)";

    ctx.fillRect(
        0,
        0,
        canvas.width,
        canvas.height
    );

    // Raster
    ctx.strokeStyle =
        "rgba(255,255,255,0.025)";

    ctx.lineWidth = 1;

    for (let x = 0; x <= BOARD_WIDTH; x++) {

        ctx.beginPath();

        ctx.moveTo(
            x * cellSize,
            0
        );

        ctx.lineTo(
            x * cellSize,
            canvas.height
        );

        ctx.stroke();
    }

    for (let y = 0; y <= BOARD_HEIGHT; y++) {

        ctx.beginPath();

        ctx.moveTo(
            0,
            y * cellSize
        );

        ctx.lineTo(
            canvas.width,
            y * cellSize
        );

        ctx.stroke();
    }

    // feste Blöcke
    for (let x = 0; x < BOARD_WIDTH; x++) {

        for (
            let y = 0;
            y < BOARD_HEIGHT;
            y++
        ) {

            if (board[x][y]) {

                drawBlock(
                    ctx,
                    x,
                    y,
                    board[x][y]
                );
            }
        }
    }

    // aktuelle Figur
    if (
        game.current &&
        game.alive
    ) {

        const projection =
            getProjectionY();

        // Schatten / Projektion
        for (
            const block of
            game.current.blocks
        ) {

            const x =
                game.current.x +
                block[0];

            const y =
                game.current.y +
                block[1] +
                projection;

            if (y >= 0) {

                drawBlock(
                    ctx,
                    x,
                    y,
                    game.current.color,
                    0.12
                );
            }
        }

        // aktuelle Figur
        for (
            const block of
            game.current.blocks
        ) {

            const x =
                game.current.x +
                block[0];

            const y =
                game.current.y +
                block[1];

            if (y >= 0) {

                drawBlock(
                    ctx,
                    x,
                    y,
                    game.current.color
                );
            }
        }
    }
}


/* =========================================================
   DRAW BLOCK
   ========================================================= */

function drawBlock(
    context,
    x,
    y,
    color,
    alpha = 1
) {

    const padding = 1;

    context.globalAlpha = alpha;

    context.fillStyle = color;

    context.fillRect(
        x * cellSize + padding,
        y * cellSize + padding,
        cellSize - padding * 2,
        cellSize - padding * 2
    );

    // leichter Glanz
    context.globalAlpha =
        alpha * 0.18;

    context.fillStyle =
        "#ffffff";

    context.fillRect(
        x * cellSize + padding,
        y * cellSize + padding,
        cellSize - padding * 2,
        2
    );

    context.globalAlpha = 1;
}


/* =========================================================
   NEXT PIECES
   ========================================================= */

function updateNextPieces() {

    for (
        let i = 0;
        i < nextContexts.length;
        i++
    ) {

        drawNextPiece(
            nextContexts[i],
            game.next[i]
        );
    }
}


function drawNextPiece(
    context,
    piece
) {

    const canvas =
        context.canvas;

    context.clearRect(
        0,
        0,
        canvas.width,
        canvas.height
    );

    context.fillStyle =
        "rgb(28,30,34)";

    context.fillRect(
        0,
        0,
        canvas.width,
        canvas.height
    );

    if (!piece) {
        return;
    }

    const previewSize =
        Math.min(
            canvas.width,
            canvas.height
        ) / 5;

    const blocks =
        piece.blocks;

    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;

    for (const block of blocks) {

        minX = Math.min(
            minX,
            block[0]
        );

        maxX = Math.max(
            maxX,
            block[0]
        );

        minY = Math.min(
            minY,
            block[1]
        );

        maxY = Math.max(
            maxY,
            block[1]
        );
    }

    const width =
        maxX - minX + 1;

    const height =
        maxY - minY + 1;

    const startX =
        (canvas.width -
            width * previewSize) / 2;

    const startY =
        (canvas.height -
            height * previewSize) / 2;

    for (const block of blocks) {

        const x =
            startX +
            (block[0] - minX) *
            previewSize;

        const y =
            startY +
            (block[1] - minY) *
            previewSize;

        context.fillStyle =
            piece.color;

        context.fillRect(
            x + 1,
            y + 1,
            previewSize - 2,
            previewSize - 2
        );
    }
}


/* =========================================================
   SCORE
   ========================================================= */

function updateScore() {

    document.getElementById(
        "score"
    ).textContent =
        String(game.score)
            .padStart(7, "0");

    document.getElementById(
        "highScore"
    ).textContent =
        String(game.highScore)
            .padStart(7, "0");

    document.getElementById(
        "level"
    ).textContent =
        String(game.level)
            .padStart(2, "0");
}


/* =========================================================
   GAME OVER
   ========================================================= */

function gameOver() {

    game.alive = false;

    if (
        game.score >
        game.highScore
    ) {

        game.highScore =
            game.score;

        localStorage.setItem(
            "tetrisHighScore",
            game.highScore
        );
    }

    updateScore();

    document
        .getElementById("gameOver")
        .classList.add("visible");
}


/* =========================================================
   RESTART
   ========================================================= */

function restartGame() {

    createBoard();

    game.alive = true;

    game.score = 0;
    game.level = 1;
    game.piecesRemaining = 10;

    game.tickRate = 500;
    game.lastTick =
        performance.now();

    game.scoreBonus = 0;
    game.difficultFlag = false;

    game.current = null;

    game.next = [
        randomPiece(),
        randomPiece(),
        randomPiece()
    ];

    document
        .getElementById("gameOver")
        .classList.remove("visible");

    updateScore();

    spawnPiece();

    resizeCanvas();
}


/* =========================================================
   KEYBOARD
   ========================================================= */

document.addEventListener(
    "keydown",
    function (event) {

        if (!game.alive) {

            restartGame();

            event.preventDefault();

            return;
        }

        let changed = false;

        switch (event.key) {

            case "ArrowLeft":
            case "a":
            case "A":

                changed =
                    movePiece(-1, 0);

                break;


            case "ArrowRight":
            case "d":
            case "D":

                changed =
                    movePiece(1, 0);

                break;


            case "ArrowDown":
            case "s":
            case "S":

                changed =
                    movePiece(0, 1);

                break;


            case "ArrowUp":
            case "w":
            case "W":

                changed =
                    rotatePiece();

                break;


            case " ":

                hardDrop();

                changed = true;

                break;
        }

        if (
            [
                "ArrowLeft",
                "ArrowRight",
                "ArrowDown",
                "ArrowUp",
                " "
            ].includes(event.key)
        ) {

            event.preventDefault();
        }

        if (changed) {
            drawBoard();
        }
    }
);


/* =========================================================
   RESIZE
   ========================================================= */

function resizeCanvas() {

    const maxHeight =
        Math.min(
            window.innerHeight - 40,
            800
        );

    const maxWidth =
        Math.min(
            window.innerWidth - 230,
            500
        );

    cellSize =
        Math.floor(
            Math.min(
                maxHeight / BOARD_HEIGHT,
                maxWidth / BOARD_WIDTH
            )
        );

    cellSize =
        Math.max(
            cellSize,
            15
        );

    canvas.width =
        BOARD_WIDTH * cellSize;

    canvas.height =
        BOARD_HEIGHT * cellSize;

    for (
        const previewCanvas
        of nextCanvases
    ) {

        previewCanvas.width =
            previewCanvas.clientWidth ||
            160;

        previewCanvas.height =
            previewCanvas.clientHeight ||
            75;
    }

    drawBoard();

    updateNextPieces();
}

window.addEventListener(
    "resize",
    resizeCanvas
);


/* =========================================================
   GAME LOOP
   ========================================================= */

function gameLoop(time) {

    if (
        game.alive &&
        time - game.lastTick >=
        game.tickRate
    ) {

        game.lastTick = time;

        if (game.current) {

            if (
                !movePiece(0, 1)
            ) {

                freezePiece();
            }
        }
        else {

            spawnPiece();
        }
    }

    drawBoard();

    requestAnimationFrame(
        gameLoop
    );
}


/* =========================================================
   START
   ========================================================= */

function init() {

    createBoard();

    game.highScore =
        Number(
            localStorage.getItem(
                "tetrisHighScore"
            ) || 0
        );

    game.score = 0;
    game.level = 1;
    game.piecesRemaining = 10;
    game.tickRate = 500;
    game.scoreBonus = 0;
    game.difficultFlag = false;
    game.alive = true;

    game.next = [
        randomPiece(),
        randomPiece(),
        randomPiece()
    ];

    game.current = null;

    resizeCanvas();

    updateScore();

    spawnPiece();

    requestAnimationFrame(
        gameLoop
    );
}

init();