// Canvas-Setup
const canvas = document.createElement("canvas");
const ctx = canvas.getContext("2d");
document.body.appendChild(canvas);

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

// Einstellungen
const CAMERA_DIST = 3;
const FOCAL_LENGTH = 0.7;

// Spielvariablen
let x = 0;
let y = 0;
let z = 0;
let vy = 0;

let trackGap = 0;
let mouseDown = 0;
let trackSx = 3;
let trackSw = 3;
let mouseX = canvas.width / 2;
let trackRows = [];

let mouseJustPressed = 0;
let mouseMode = 1;
let keyInput = {};

// SCORE
let score = 0;
let highScore = Number(localStorage.getItem("skydreamsHighScore")) || 0;
let isNewHighScore = false;


// --------------------------------------------------
// SCORE
// --------------------------------------------------

function updateScore() {
    score = Math.floor(z * 10);

    if (score > highScore) {
        highScore = score;
        isNewHighScore = true;
        localStorage.setItem("skydreamsHighScore", highScore);
    }
}

function drawScore() {
    ctx.save();

    // Score-Hintergrund
    ctx.fillStyle = "rgba(0, 0, 0, 0.35)";
    ctx.fillRect(15, 15, 235, 85);

    // Aktueller Score
    ctx.font = "bold 24px Arial";
    ctx.textAlign = "left";
    ctx.textBaseline = "top";
    ctx.fillStyle = "#ffffff";

    ctx.fillText("SCORE: " + score, 28, 25);

    // Highscore
    ctx.font = "bold 18px Arial";
    ctx.fillStyle = "#ffe66d";

    ctx.fillText("HIGH SCORE: " + highScore, 28, 62);

    ctx.restore();
}


// --------------------------------------------------
// GAME OVER
// --------------------------------------------------

function drawGameOver() {
    ctx.save();

    ctx.fillStyle = "rgba(0, 0, 0, 0.6)";
    ctx.fillRect(
        0,
        0,
        canvas.width,
        canvas.height
    );

    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    // Game Over
    ctx.font = "bold 52px Arial";
    ctx.fillStyle = "#ffffff";

    ctx.fillText(
        "GAME OVER",
        canvas.width / 2,
        canvas.height / 2 - 100
    );

    // Score
    ctx.font = "bold 30px Arial";
    ctx.fillStyle = "#ffffff";

    ctx.fillText(
        "SCORE: " + score,
        canvas.width / 2,
        canvas.height / 2 - 40
    );

    // Highscore
    ctx.font = "bold 24px Arial";
    ctx.fillStyle = "#ffe66d";

    ctx.fillText(
        "HIGH SCORE: " + highScore,
        canvas.width / 2,
        canvas.height / 2 + 5
    );

    // Neuer Highscore
    if (isNewHighScore) {
        ctx.font = "bold 28px Arial";
        ctx.fillStyle = "#7fffd4";

        ctx.fillText(
            "★ NEW HIGH SCORE! ★",
            canvas.width / 2,
            canvas.height / 2 + 60
        );
    }

    // Neustart
    ctx.font = "18px Arial";
    ctx.fillStyle = "#ffffff";

    ctx.fillText(
        "KLICKEN / TIPPEN oder R zum Neustart",
        canvas.width / 2,
        canvas.height / 2 + 110
    );

    ctx.restore();
}


// --------------------------------------------------
// SPIEL NEUSTARTEN
// --------------------------------------------------

function restartGame() {
    x = 0;
    y = 0;
    z = 0;
    vy = 0;

    trackGap = 0;
    trackSx = 3;
    trackSw = 3;
    trackRows = [];

    score = 0;
    isNewHighScore = false;
}


// --------------------------------------------------
// HSL
// --------------------------------------------------

function hsl(h, s, l, a = 1) {
    ctx.fillStyle =
        "hsla(" +
        h +
        "," +
        s +
        "%," +
        l +
        "%," +
        a +
        ")";
}


// --------------------------------------------------
// 3D ZU 2D
// --------------------------------------------------

function project(px, py, dz) {
    const scale =
        (canvas.height * FOCAL_LENGTH) / dz;

    const screenX =
        canvas.width / 2 +
        (
            px -
            x +
            ((dz - CAMERA_DIST) ** 2 / 50) *
            Math.cos((z + dz) / 49)
        ) *
        scale;

    const screenY =
        canvas.height / 2 -
        (
            py -
            2 +
            (dz * dz) / 50
        ) *
        scale;

    return [
        screenX,
        screenY,
        scale
    ];
}


// --------------------------------------------------
// HAUPT UPDATE
// --------------------------------------------------

function update() {

    let i, j, r;
    let px, py, s;
    let ax, ay, bx, by;
    let ex, ey, fx, fy;


    // --------------------------------------------------
    // HIMMEL
    // --------------------------------------------------

    for (i = 500; i--; ) {

        hsl(
            170 + i / 9 + z,
            70,
            70 - i / 9
        );

        ctx.fillRect(
            0,
            (canvas.height * i) / 500,
            canvas.width,
            canvas.height / 250
        );

        // Sterne
        hsl(0, 0, 99);

        ctx.fillRect(
            (i * i + (z * i) / 99) % canvas.width,
            (i ** 3.3) % canvas.height,
            ((i % 4) * canvas.height) / 500,
            ((i % 4) * canvas.height) / 500
        );
    }


    // --------------------------------------------------
    // RENNSTRECKE
    // --------------------------------------------------

    for (
        r = (z + 40) | 0;
        r > z;
        r--
    ) {

        // Neue Reihen erzeugen
        for (
            i = trackRows.length;
            i <= r;
        ) {

            if (
                trackGap < -8 &&
                Math.random() <
                Math.min(0.2, i / 1e4)
            ) {

                trackGap =
                    2 +
                    Math.min(4, i / 400);
            }

            if (Math.random() < 0.1) {

                trackSw =
                    (2 + Math.random() * 3) | 0;

                trackSx =
                    Math.max(
                        0,
                        Math.min(
                            7 - trackSw,
                            (
                                trackSx -
                                2 +
                                Math.random() * 5
                            ) | 0
                        )
                    );
            }

            trackGap--;

            const row = [];

            trackRows[i++] = row;

            for (j = 7; j--; ) {

                row[j] = Boolean(

                    (i < 35 ? 1 : 0) |

                    (Math.random() > 0.9 ? 1 : 0) |

                    (
                        trackGap < 0 &&
                        trackSx <= j &&
                        j < trackSx + trackSw &&
                        Math.random() >
                        Math.min(0.2, z / 1e4)
                        ? 1
                        : 0
                    )
                );
            }
        }


        // Kacheln zeichnen
        for (j = 2; j--; ) {

            for (i = 7; i--; ) {

                if (
                    trackRows[r] &&
                    trackRows[r][i]
                ) {

                    [ax, ay] =
                        project(
                            i - 3.5,
                            0,
                            r - z
                        );

                    [bx, by] =
                        project(
                            i - 2.5,
                            0,
                            r - z
                        );

                    [ex, ey] =
                        project(
                            i - 3.5,
                            0,
                            r - z + 1
                        );

                    [fx, fy] =
                        project(
                            i - 2.5,
                            0,
                            r - z + 1
                        );


                    if (j) {

                        // Seitenwand
                        hsl(
                            99 +
                            (r >> 7) * 70,
                            60,
                            30 +
                            ((r + i) & 1) * 9
                        );

                        ctx.fillRect(
                            ex,
                            ey,
                            fx - ex,
                            ((40 - r + z) / 30) *
                            canvas.height
                        );

                    } else {

                        // Vorderseite
                        hsl(
                            99 +
                            (r >> 7) * 70,
                            60,
                            9 +
                            ((r + i) & 1) * 5
                        );

                        ctx.fillRect(
                            ax,
                            ay,
                            bx - ax,
                            ((40 - r + z) / 30) *
                            canvas.height
                        );


                        // Oberfläche
                        hsl(
                            99 +
                            (r >> 7) * 70,
                            60,
                            60 +
                            ((r + i) & 1) * 30
                        );

                        ctx.beginPath();

                        ctx.lineTo(ax, ay);
                        ctx.lineTo(bx, by);
                        ctx.lineTo(fx, fy);
                        ctx.lineTo(ex, ey);

                        ctx.fill();
                    }
                }
            }
        }
    }


    // --------------------------------------------------
    // SPIELERPOSITION
    // --------------------------------------------------

    const currentTileIndex =
        Math.round(x + 3);

    const playerRowIndex =
        (z + CAMERA_DIST) | 0;


    // --------------------------------------------------
    // SCHATTEN
    // --------------------------------------------------

    if (
        y >= 0 &&
        trackRows[playerRowIndex] &&
        trackRows[playerRowIndex][currentTileIndex]
    ) {

        hsl(0, 0, 0, 0.5);

        [px, py, s] =
            project(
                x,
                0,
                CAMERA_DIST
            );

        ctx.beginPath();

        ctx.ellipse(
            px,
            py,
            s / 4,
            s / 9,
            0,
            0,
            Math.PI * 2
        );

        ctx.fill();
    }


    // --------------------------------------------------
    // SPIELER
    // --------------------------------------------------

    for (i = 99; i--; ) {

        hsl(
            z / 9 - i / 3,
            90,
            99 - i * 0.7
        );

        [px, py, s] =
            project(
                x + 0.1 - i / 1e3,
                y + 0.35 - i / 1e3,
                CAMERA_DIST
            );

        ctx.beginPath();

        ctx.ellipse(
            px,
            py,
            (i * s) / 300,
            (i * s) / 300,
            0,
            0,
            Math.PI * 2
        );

        ctx.fill();
    }


    // --------------------------------------------------
    // PHYSIK & STEUERUNG
    // --------------------------------------------------

    if (y > -4) {

        if (mouseMode) {

            // Maus / Touch
            x +=
                mouseX /
                canvas.width /
                2 -
                0.25;

        } else {

            // Rechts
            if (
                keyInput["d"] ||
                keyInput["D"] ||
                keyInput["ArrowRight"]
            ) {

                x += 0.1;
            }

            // Links
            if (
                keyInput["a"] ||
                keyInput["A"] ||
                keyInput["ArrowLeft"]
            ) {

                x -= 0.1;
            }
        }


        // Gravitation
        y += vy -= 0.006;


        // Geschwindigkeit
        z += Math.min(
            0.5,
            0.2 + z / 5e3
        );


        // SCORE AKTUALISIEREN
        updateScore();


        // Kollision / Landung
        if (
            y < 0 &&
            y > -0.3 &&
            trackRows[playerRowIndex] &&
            trackRows[playerRowIndex][currentTileIndex]
        ) {

            y = vy = mouseDown;

            if ("ontouchstart" in window) {
                mouseDown = 0;
            }
        }

    } else {

        // GAME OVER
        updateScore();

        if (mouseJustPressed) {
            restartGame();
        }
    }


    // --------------------------------------------------
    // SCORE ANZEIGEN
    // --------------------------------------------------

    drawScore();


    // --------------------------------------------------
    // GAME OVER ANZEIGEN
    // --------------------------------------------------

    if (y <= -4) {
        drawGameOver();
    }


    mouseJustPressed = 0;
}


// --------------------------------------------------
// MAUS
// --------------------------------------------------

function handleMouseMove(e) {
    mouseX = e.clientX;
}

function handleMouseDown() {
    mouseDown = 0.1;
    mouseJustPressed = 1;
    mouseMode = 1;
}

function handleMouseUp() {
    mouseDown = 0;
}


// Maus Events
window.addEventListener(
    "mousemove",
    handleMouseMove
);

window.addEventListener(
    "mousedown",
    handleMouseDown
);

window.addEventListener(
    "mouseup",
    handleMouseUp
);


// --------------------------------------------------
// TASTATUR
// --------------------------------------------------

window.addEventListener(
    "keydown",
    function(e) {

        mouseMode = 0;

        keyInput[e.key] = 1;


        // R = Neustart
        if (
            e.key === "r" ||
            e.key === "R"
        ) {

            restartGame();
        }


        // Springen
        if (
            e.key === " " ||
            e.key === "ArrowUp" ||
            e.key === "w" ||
            e.key === "W"
        ) {

            mouseDown = 0.1;
            mouseJustPressed = 1;
        }
    }
);


window.addEventListener(
    "keyup",
    function(e) {

        keyInput[e.key] = 0;

        if (
            e.key === " " ||
            e.key === "ArrowUp" ||
            e.key === "w" ||
            e.key === "W"
        ) {

            mouseDown = 0;
        }
    }
);


// --------------------------------------------------
// RESIZE
// --------------------------------------------------

window.addEventListener(
    "resize",
    function() {

        canvas.width =
            window.innerWidth;

        canvas.height =
            window.innerHeight;
    }
);


// --------------------------------------------------
// MOBILE TOUCH
// --------------------------------------------------

if ("ontouchstart" in window) {

    window.addEventListener(
        "touchstart",
        function() {
            handleMouseDown();
        },
        { passive: true }
    );


    window.addEventListener(
        "touchend",
        function() {
            handleMouseUp();
        },
        { passive: true }
    );


    window.addEventListener(
        "touchmove",
        function(e) {

            if (e.touches.length > 0) {

                mouseX =
                    e.touches[0].clientX;
            }
        },
        { passive: true }
    );
}


// --------------------------------------------------
// GAME LOOP
// --------------------------------------------------

let frameTimeLastMS = 0;
let frameTimeBufferMS = 0;


function loop(frameTimeMS = 0) {

    requestAnimationFrame(loop);


    const delta =
        frameTimeMS -
        frameTimeLastMS;

    frameTimeLastMS =
        frameTimeMS;


    frameTimeBufferMS += delta;


    frameTimeBufferMS =
        Math.min(
            frameTimeBufferMS,
            50
        );


    for (
        ;
        frameTimeBufferMS >= 0;
        frameTimeBufferMS -= 1000 / 60
    ) {

        update();
    }
}


// --------------------------------------------------
// SPIEL STARTEN
// --------------------------------------------------

loop();