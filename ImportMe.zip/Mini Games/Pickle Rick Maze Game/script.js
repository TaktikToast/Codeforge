function rand(max) {
  return Math.floor(Math.random() * max);
}

function shuffle(a) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function changeBrightness(factor, sprite) {
  var virtCanvas = document.createElement("canvas");
  virtCanvas.width = 500;
  virtCanvas.height = 500;
  var context = virtCanvas.getContext("2d");
  try {
    context.drawImage(sprite, 0, 0, 500, 500);
    var imgData = context.getImageData(0, 0, 500, 500);
    for (let i = 0; i < imgData.data.length; i += 4) {
      imgData.data[i]     = imgData.data[i]     * factor;
      imgData.data[i + 1] = imgData.data[i + 1] * factor;
      imgData.data[i + 2] = imgData.data[i + 2] * factor;
    }
    context.putImageData(imgData, 0, 0);
    var spriteOutput = new Image();
    spriteOutput.src = virtCanvas.toDataURL();
    virtCanvas.remove();
    return spriteOutput;
  } catch(e) {
    return sprite;
  }
}

function displayVictoryMess(moves) {
  document.getElementById("moves").innerHTML = "You Moved " + moves + " Steps.";
  toggleVisablity("Message-Container");
}

function toggleVisablity(id) {
  if (document.getElementById(id).style.visibility == "visible") {
    document.getElementById(id).style.visibility = "hidden";
  } else {
    document.getElementById(id).style.visibility = "visible";
  }
}

function Maze(Width, Height) {
  var mazeMap;
  var width = Width;
  var height = Height;
  var startCoord, endCoord;
  var dirs = ["n", "s", "e", "w"];
  var modDir = {
    n: { y: -1, x: 0, o: "s" },
    s: { y: 1,  x: 0, o: "n" },
    e: { y: 0,  x: 1, o: "w" },
    w: { y: 0,  x: -1, o: "e" }
  };

  this.map = function() { return mazeMap; };
  this.startCoord = function() { return startCoord; };
  this.endCoord = function() { return endCoord; };

  function genMap() {
    mazeMap = new Array(height);
    for (let y = 0; y < height; y++) {
      mazeMap[y] = new Array(width);
      for (let x = 0; x < width; ++x) {
        mazeMap[y][x] = { n: false, s: false, e: false, w: false, visited: false, priorPos: null };
      }
    }
  }

  function defineMaze() {
    var isComp = false;
    var move = false;
    var cellsVisited = 1;
    var numLoops = 0;
    var maxLoops = 0;
    var pos = { x: 0, y: 0 };
    var numCells = width * height;
    while (!isComp) {
      move = false;
      mazeMap[pos.x][pos.y].visited = true;
      if (numLoops >= maxLoops) {
        shuffle(dirs);
        maxLoops = Math.round(rand(height / 8));
        numLoops = 0;
      }
      numLoops++;
      for (let index = 0; index < dirs.length; index++) {
        var direction = dirs[index];
        var nx = pos.x + modDir[direction].x;
        var ny = pos.y + modDir[direction].y;
        if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
          if (!mazeMap[nx][ny].visited) {
            mazeMap[pos.x][pos.y][direction] = true;
            mazeMap[nx][ny][modDir[direction].o] = true;
            mazeMap[nx][ny].priorPos = pos;
            pos = { x: nx, y: ny };
            cellsVisited++;
            move = true;
            break;
          }
        }
      }
      if (!move) { pos = mazeMap[pos.x][pos.y].priorPos; }
      if (numCells == cellsVisited) { isComp = true; }
    }
  }

  function defineStartEnd() {
    switch (rand(4)) {
      case 0: startCoord = { x: 0, y: 0 };                endCoord = { x: height-1, y: width-1 }; break;
      case 1: startCoord = { x: 0, y: width-1 };           endCoord = { x: height-1, y: 0 };       break;
      case 2: startCoord = { x: height-1, y: 0 };          endCoord = { x: 0, y: width-1 };        break;
      case 3: startCoord = { x: height-1, y: width-1 };    endCoord = { x: 0, y: 0 };              break;
    }
  }

  genMap();
  defineStartEnd();
  defineMaze();
}

function DrawMaze(Maze, ctx, cellsize, endSprite = null) {
  var map = Maze.map();
  var cellSize = cellsize;
  var drawEndMethod;
  ctx.lineWidth = cellSize / 40;

  this.redrawMaze = function(size) {
    cellSize = size;
    ctx.lineWidth = cellSize / 50;
    drawMap();
    drawEndMethod();
  };

  function drawCell(xCord, yCord, cell) {
    var x = xCord * cellSize;
    var y = yCord * cellSize;
    ctx.strokeStyle = "#000000";
    if (cell.n === false) { ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + cellSize, y); ctx.stroke(); }
    if (cell.s === false) { ctx.beginPath(); ctx.moveTo(x, y + cellSize); ctx.lineTo(x + cellSize, y + cellSize); ctx.stroke(); }
    if (cell.e === false) { ctx.beginPath(); ctx.moveTo(x + cellSize, y); ctx.lineTo(x + cellSize, y + cellSize); ctx.stroke(); }
    if (cell.w === false) { ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + cellSize); ctx.stroke(); }
  }

  function drawMap() {
    for (let x = 0; x < map.length; x++) {
      for (let y = 0; y < map[x].length; y++) {
        drawCell(x, y, map[x][y]);
      }
    }
  }

  function drawEndFlag() {
    var coord = Maze.endCoord();
    var gridSize = 4;
    var fraction = cellSize / gridSize - 2;
    var colorSwap = true;
    for (let y = 0; y < gridSize; y++) {
      if (gridSize % 2 == 0) { colorSwap = !colorSwap; }
      for (let x = 0; x < gridSize; x++) {
        ctx.beginPath();
        ctx.rect(coord.x * cellSize + x * fraction + 4.5, coord.y * cellSize + y * fraction + 4.5, fraction, fraction);
        ctx.fillStyle = colorSwap ? "rgba(0,0,0,0.8)" : "rgba(255,255,255,0.8)";
        ctx.fill();
        colorSwap = !colorSwap;
      }
    }
  }

  function drawEndSprite() {
    var offsetLeft = cellSize / 50;
    var offsetRight = cellSize / 25;
    var coord = Maze.endCoord();
    ctx.drawImage(endSprite, 0, 0, endSprite.width, endSprite.height,
      coord.x * cellSize + offsetLeft, coord.y * cellSize + offsetLeft,
      cellSize - offsetRight, cellSize - offsetRight);
  }

  function clear() {
    var canvasSize = cellSize * map.length;
    ctx.clearRect(0, 0, canvasSize, canvasSize);
  }

  drawEndMethod = (endSprite != null) ? drawEndSprite : drawEndFlag;
  clear();
  drawMap();
  drawEndMethod();
}

function Player(maze, c, _cellsize, onComplete, sprite = null) {
  var ctx = c.getContext("2d");
  var moves = 0;
  var player = this;
  var map = maze.map();
  var cellCoords = { x: maze.startCoord().x, y: maze.startCoord().y };
  var cellSize = _cellsize;
  var halfCellSize = cellSize / 2;

  var drawSprite = (sprite != null) ? drawSpriteImg : drawSpriteCircle;

  this.redrawPlayer = function(_cellsize) {
    cellSize = _cellsize;
    drawSprite(cellCoords);
  };

  function drawSpriteCircle(coord) {
    ctx.beginPath();
    ctx.fillStyle = "yellow";
    ctx.arc(
      (coord.x + 1) * cellSize - halfCellSize,
      (coord.y + 1) * cellSize - halfCellSize,
      halfCellSize - 2, 0, 2 * Math.PI
    );
    ctx.fill();
    if (coord.x === maze.endCoord().x && coord.y === maze.endCoord().y) {
      onComplete(moves);
      player.unbindKeyDown();
    }
  }

  function drawSpriteImg(coord) {
    var offsetLeft = cellSize / 50;
    var offsetRight = cellSize / 25;
    ctx.drawImage(sprite, 0, 0, sprite.width, sprite.height,
      coord.x * cellSize + offsetLeft, coord.y * cellSize + offsetLeft,
      cellSize - offsetRight, cellSize - offsetRight);
    if (coord.x === maze.endCoord().x && coord.y === maze.endCoord().y) {
      onComplete(moves);
      player.unbindKeyDown();
    }
  }

  function removeSprite(coord) {
    var offsetLeft = cellSize / 50;
    var offsetRight = cellSize / 25;
    ctx.clearRect(
      coord.x * cellSize + offsetLeft, coord.y * cellSize + offsetLeft,
      cellSize - offsetRight, cellSize - offsetRight
    );
  }

  // Tasteneingaben speichern (wie im Runner-Projekt mit e.key)
  var keys = {};

  function handleKeyDown(e) {
    keys[e.key] = true;
  }

  function handleKeyUp(e) {
    keys[e.key] = false;
  }

  // Bewegung wird pro Frame/Tick ausgeführt
  function processKeys() {
    var moved = false;
    var cell = map[cellCoords.x][cellCoords.y];

    if (keys["ArrowLeft"] || keys["a"] || keys["A"]) {
      if (cell.w === true) {
        removeSprite(cellCoords);
        cellCoords = { x: cellCoords.x - 1, y: cellCoords.y };
        moved = true;
      }
      // Taste danach zurücksetzen damit man nicht dauerhaft gleitet
      keys["ArrowLeft"] = false;
      keys["a"] = false;
      keys["A"] = false;
    } else if (keys["ArrowRight"] || keys["d"] || keys["D"]) {
      if (cell.e === true) {
        removeSprite(cellCoords);
        cellCoords = { x: cellCoords.x + 1, y: cellCoords.y };
        moved = true;
      }
      keys["ArrowRight"] = false;
      keys["d"] = false;
      keys["D"] = false;
    } else if (keys["ArrowUp"] || keys["w"] || keys["W"]) {
      if (cell.n === true) {
        removeSprite(cellCoords);
        cellCoords = { x: cellCoords.x, y: cellCoords.y - 1 };
        moved = true;
      }
      keys["ArrowUp"] = false;
      keys["w"] = false;
      keys["W"] = false;
    } else if (keys["ArrowDown"] || keys["s"] || keys["S"]) {
      if (cell.s === true) {
        removeSprite(cellCoords);
        cellCoords = { x: cellCoords.x, y: cellCoords.y + 1 };
        moved = true;
      }
      keys["ArrowDown"] = false;
      keys["s"] = false;
      keys["S"] = false;
    }

    if (moved) {
      moves++;
      drawSprite(cellCoords);
    }
  }

  this.bindKeyDown = function() {
    window.addEventListener("keydown", handleKeyDown, false);
    window.addEventListener("keyup", handleKeyUp, false);

    // Tick: Bewegung prüfen
    player._tickInterval = setInterval(processKeys, 100);

    if ($.fn.swipe) {
      $("#view").swipe({
        swipe: function(event, direction) {
          var cell = map[cellCoords.x][cellCoords.y];
          var moved = false;
          if (direction === "left"  && cell.w) { removeSprite(cellCoords); cellCoords = { x: cellCoords.x - 1, y: cellCoords.y };     moved = true; }
          if (direction === "right" && cell.e) { removeSprite(cellCoords); cellCoords = { x: cellCoords.x + 1, y: cellCoords.y };     moved = true; }
          if (direction === "up"    && cell.n) { removeSprite(cellCoords); cellCoords = { x: cellCoords.x,     y: cellCoords.y - 1 }; moved = true; }
          if (direction === "down"  && cell.s) { removeSprite(cellCoords); cellCoords = { x: cellCoords.x,     y: cellCoords.y + 1 }; moved = true; }
          if (moved) { moves++; drawSprite(cellCoords); }
        },
        threshold: 0
      });
    }
  };

  this.unbindKeyDown = function() {
    window.removeEventListener("keydown", handleKeyDown, false);
    window.removeEventListener("keyup", handleKeyUp, false);
    clearInterval(player._tickInterval);
    if ($.fn.swipe) { $("#view").swipe("destroy"); }
  };

  drawSprite(maze.startCoord());
  this.bindKeyDown();
}

var mazeCanvas = document.getElementById("mazeCanvas");
var ctx = mazeCanvas.getContext("2d");
var sprite;
var finishSprite;
var maze, draw, player;
var cellSize;
var difficulty;

window.onload = function() {
  let viewWidth  = $("#view").width();
  let viewHeight = $("#view").height();
  if (viewHeight < viewWidth) {
    ctx.canvas.width  = viewHeight - viewHeight / 100;
    ctx.canvas.height = viewHeight - viewHeight / 100;
  } else {
    ctx.canvas.width  = viewWidth - viewWidth / 100;
    ctx.canvas.height = viewWidth - viewWidth / 100;
  }

  var completeOne = false;
  var completeTwo = false;
  var isComplete = () => {
    if (completeOne === true && completeTwo === true) {
      setTimeout(function() { makeMaze(); }, 500);
    }
  };

  sprite = new Image();
  sprite.crossOrigin = "Anonymous";
  sprite.src = "https://i.imgur.com/PfRWr3X.png?" + new Date().getTime();
  sprite.onload = function() {
    sprite = changeBrightness(1.2, sprite);
    completeOne = true;
    isComplete();
  };

  finishSprite = new Image();
  finishSprite.crossOrigin = "Anonymous";
  finishSprite.src = "https://i.imgur.com/iQ7mU25.png?" + new Date().getTime();
  finishSprite.onload = function() {
    finishSprite = changeBrightness(1.1, finishSprite);
    completeTwo = true;
    isComplete();
  };
};

window.onresize = function() {
  let viewWidth  = $("#view").width();
  let viewHeight = $("#view").height();
  if (viewHeight < viewWidth) {
    ctx.canvas.width  = viewHeight - viewHeight / 100;
    ctx.canvas.height = viewHeight - viewHeight / 100;
  } else {
    ctx.canvas.width  = viewWidth - viewWidth / 100;
    ctx.canvas.height = viewWidth - viewWidth / 100;
  }
  cellSize = mazeCanvas.width / difficulty;
  if (player != null) {
    draw.redrawMaze(cellSize);
    player.redrawPlayer(cellSize);
  }
};

function makeMaze() {
  if (player != undefined && player != null) {
    player.unbindKeyDown();
    player = null;
  }
  var e = document.getElementById("diffSelect");
  difficulty = e.options[e.selectedIndex].value;
  cellSize = mazeCanvas.width / difficulty;
  maze   = new Maze(difficulty, difficulty);
  draw   = new DrawMaze(maze, ctx, cellSize, finishSprite);
  player = new Player(maze, mazeCanvas, cellSize, displayVictoryMess, sprite);
  document.getElementById("mazeContainer").style.opacity = "1";
}